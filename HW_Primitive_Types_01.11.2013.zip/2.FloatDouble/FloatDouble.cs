﻿using System;

namespace _2.FloatDouble
{
    class FloatDouble
    {
        static void Main(string[] args)
        {
            double first = 34.5678309023;
            float second = 12.345f;
            float third = 8923.1234857f;
            float forth = 3456.091f;
            Console.WriteLine("Enter your age:");
            int age = int.Parse(Console.ReadLine());
        }
    }
}

﻿using System;

namespace _6.Boolean
{
    class Program
    {
        static void Main(string[] args)
        {
            bool isFemale = false;
        }
    }
}

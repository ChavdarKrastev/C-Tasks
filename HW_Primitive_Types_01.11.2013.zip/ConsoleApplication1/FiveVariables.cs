﻿using System;


namespace ConsoleApplication1
{
    class Variables
    {
        static void Main(string[] args)
        {
            ushort first = 52130;
            sbyte second = -115;
            int third = 4825932;
            byte forth = 97;
            short fifth = -10000;
        }
    }
}

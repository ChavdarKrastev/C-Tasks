﻿using System;


namespace _4.Hexadecimal
{
    class Hexadecimal
    {
        static void Main(string[] args)
        {
            byte hex = 0xFE;
            Console.WriteLine(hex);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _9.Triangle
{
    class Triangle
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.UTF8;
            System.Console.WriteLine("              \u00A9        ");
            System.Console.WriteLine("            \u00A9   \u00A9      ");
            System.Console.WriteLine("          \u00A9       \u00A9     ");
            System.Console.WriteLine("        \u00A9   \u00A9   \u00A9   \u00A9");
        }
    }
}

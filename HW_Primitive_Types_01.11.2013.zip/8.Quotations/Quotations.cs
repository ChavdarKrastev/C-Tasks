﻿using System;

namespace _8.Quotations
{
    class Quotations
    {
        static void Main(string[] args)
        {
            string quotA = "The \"use\" of quotations causes difficulties.";
            string quotB = @"The ""use"" of quotations causes difficulties.";
        }
    }
}

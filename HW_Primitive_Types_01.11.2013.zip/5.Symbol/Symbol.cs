﻿using System;


namespace _5.Symbol
{
    class Symbol
    {
        static void Main(string[] args)
        {
            char unicode72 = '\u0048';
            Console.WriteLine(unicode72);
        }
    }
}
